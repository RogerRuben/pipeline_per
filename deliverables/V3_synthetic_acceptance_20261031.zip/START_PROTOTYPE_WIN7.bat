@echo off
setlocal
chcp 65001 >nul
"%~dp0..\..\runtime\python38\python.exe" -X utf8 "%~dp0..\..\tools\product_portable.py" start --output "%~dp0." %*
if errorlevel 1 (
  if not defined PRODUCT_NO_PAUSE pause
  exit /b 1
)
endlocal
